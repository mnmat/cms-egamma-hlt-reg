#include "Analysis/HLTAnalyserPy/interface/FiltFuncs.h"
#include "Analysis/HLTAnalyserPy/interface/RateFuncs.h"
#include "Analysis/HLTAnalyserPy/interface/QCDWeightCalc.h"
#include <map>
#include <vector>
